function HTTPRequestSystem() {
	this._init();
}

//make authToken static
HTTPRequestSystem.authToken = null;

HTTPRequestSystem.setDebugMode = function(mode) {
	HTTPRequestSystem.debugMode = mode;
}

HTTPRequestSystem.registerToken = function(strToken) {
	HTTPRequestSystem.authToken = strToken;
	registerToken(strToken);
}

HTTPRequestSystem.destroyToken = function() {
	HTTPRequestSystem.registerToken(null);
}

HTTPRequestSystem.prototype = {


	getDocs: function() {
		var query = HTTPRequestSystem.urls.documentsList;
		this._makeRegularRequest (query);
	},

	attemptLogin: function( cObj) {
		this._makeLoginRequest( cObj );
	},

	addEventListener : function(strEventType, fnCallback) {
		this.events[strEventType].push(fnCallback);
	},

	removeEventListener : function(strEventType, fnCallback) {
		for (var i=0; i<this.events[strEventType].length, i++;) {
			if(this.events[strEventType][i] === fnCallback) {
				this.events[strEventType][i] = function(){};
				var deleted = this.events[strEventType][i];
				this.events[strEventType].sort ( function(a, b) {
					return (a === deleted)? 1: (b !== deleted)? -1: 0;
				});
				this.events[strEventType].pop();
			}
		}
	},

	_init: function () {
		this.$ = YAHOO.util.Dom.get;
		this.events = {
			requestSucceeded: [],
			requestFailed: [],
			uploadSucceeded: [],
			uploadFailed: []
		}
		this._callback.$init( this );
	},
	
	_notifyEventListeners : function(strEventType, responseObj) {
		var listeners = this.events[strEventType];
		for(var i=0; i<listeners.length; i++) {
			listeners[i](responseObj);
		}
	},

	// oCredentials: { USERNAME:"" USERPASS:"", LOGINTOKEN:"", LOGINCAPTCHA:"" }
	_makeArgs: function (oCredentials, template) {
		var requestArgs = template;
		for (fieldName in oCredentials) {
			switch (fieldName) {
				case "LOGINTOKEN":
					var pattern = HTTPRequestSystem.patterns.
						makeCustomPlaceholder(fieldName);
					requestArgs += HTTPRequestSystem.templates.tokenSegment;
					requestArgs.replace(pattern, HTTPRequestSystem.authToken);
					break;
				case "LOGINCAPTCHA":
					var pattern = HTTPRequestSystem.patterns.
						makeCustomPlaceholder(fieldName);
					requestArgs += HTTPRequestSystem.templates.logincaptcha;
					requestArgs.replace(pattern, oCredentials[fieldName]);
					break;
				default:
					var pattern = HTTPRequestSystem.patterns.
						makeCustomPlaceholder(fieldName);
					var value = encodeURIComponent(oCredentials[fieldName]);
					requestArgs = requestArgs.replace(pattern, value);
					break;
			}
		}
		return requestArgs;
	},

	_makeLoginRequest: function (oCredentials) {
		var template = HTTPRequestSystem.templates.initialRequest;
		var args = this._makeArgs (oCredentials, template);
		YAHOO.util.Connect.asyncRequest('POST', HTTPRequestSystem.urls.login,
			this._callback, args );
	},
	
	_makeRegularRequest: function( customQuery ) {
		if (HTTPRequestSystem.authToken) {
			YAHOO.util.Connect.initHeader (
				'Authorization', 'GoogleLogin auth=' + 
				HTTPRequestSystem.authToken);
			YAHOO.util.Connect.asyncRequest('GET', customQuery, 
				this._callback);  
		}
	},

	_callback: {
		success: null,
		failure: null,
		scope: null,
		$init: function ( scope ) {
			this.scope = scope;
			this.success = function(oResponse) {
				scope._notifyEventListeners("requestSucceeded", oResponse);
			}			
			this.failure = function(oResponse) {
				// if request failed, there might be a captcha token around...
				var match = oResponse.responseText.match (
					/CaptchaToken=([^\n]*)/ );
				var captchaToken = match ? match[1]: null;
				HTTPRequestSystem.registerToken(captchaToken);
				scope._notifyEventListeners("requestFailed", oResponse);
			}
		},
	}
}

HTTPRequestSystem.templates = {
	initialRequest:	"accountType=GOOGLE&" +
					"Email=%USERNAME%&" +
					"Passwd=%USERPASS%&" +
					"service=writely&" +
					"source=Drag_n_Share_Alpha_1.0",
	tokenSegment:	"&logintoken=%LOGINTOKEN%",
	logincaptcha:	"&logincaptcha=%LOGINCAPTCHA%",
}

HTTPRequestSystem.patterns = {
	placeHolder: /%[^%]*?%/,
	makeCustomPlaceholder: function(custStr, bGlobal) {
		return new RegExp("%"+custStr+"%", (bGlobal? "g": ""));
	}
}

HTTPRequestSystem.urls = {
	login: 			"https://www.google.com/accounts/ClientLogin",
	documentsList:	"http://docs.google.com/feeds/" +
					"documents/private/full",
}

YAHOO.register("HTTPRequestSystem", HTTPRequestSystem, {version: "1", build: "1"});