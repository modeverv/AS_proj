/**
 * DragSystem.js
 * Declares all drag needed functions
 * requires.
 */


function DragSystem(){


}

//prevent default handler on drag enter
// TODO: check file type before sending it to UPLOAD			
function doDragEnter(event)
{
	// this handler acts as the receiver
	event.preventDefault();
}
function doDragOver(event)
{
	// this handler acts as the receiver
	event.preventDefault();
}
function doDragLeave(event)
{
	event.preventDefault();
}

function doDrop(event)
{
  var fileList = event.dataTransfer.getData("application/x-vnd.adobe.air.file-list");
  dropFiles(fileList);
}

function doDragEnd(event)
{

}			
	
YAHOO.register("DragSystem", DragSystem, {version: "1", build: "1"});
