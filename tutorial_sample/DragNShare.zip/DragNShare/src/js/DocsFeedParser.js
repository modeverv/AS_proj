﻿function DocsFeedParser() {
	this.$init();	
}
DocsFeedParser.prototype = {
	$init: function() {
		this.$ = YAHOO.util.Dom.get;
		this.ds = null;
		this._parseXML.owner = this;
	},
	
	updateDocsList : function( oResponse ) {
		var src = this._makeXMLDoc(oResponse.responseText);
		this.ds = this._makeDS(src);
		this._updateRecords(this.ds);
		
	},
	
	_updateRecords : function( newDS) {
		newDS.sendRequest("", this._datasourceRequestResponse, this);
	},
    	
	_datasourceRequestResponse: function(request, response){
		 if(response && ! response.error){
		 	if(response.results && response.results.length){
			this._fireNotifications(response.results);
			}else{
			 	this._fireNotifications([]);	
			}
		 }

	},
    	
	_fireNotifications: function(data){
		var newHash = {};
		for(var i=data.length-1;i>=0;i--){
			data[i].title = data[i].title.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&apos;")
			newHash[data[i].id]=data[i];
		}
		
		if(dnshare.oldData){
			var oldHash = dnshare.oldData;
			var message = [];
			for(var id in newHash)
				if(!oldHash[id]){
					message.push(newHash[id].author_name+' added file '+newHash[id].title);
					dnshare.gridUI.addRow(newHash[id], 0);
					var row = dnshare.gridUI.getRecord(0);
					newHash[id].row = row;
					dnshare.gridUI.highlightRow	( row );
				}

			for(var id in oldHash)
				if(!newHash[id]){
					message.push(oldHash[id].author_name+' removed file '+oldHash[id].title);
					dnshare.gridUI.deleteRow(oldHash[id].row);

				}
				else{
					if(newHash[id].updated>oldHash[id].updated){
						message.push(oldHash[id].author_name+' modified file'+oldHash[id].title);

						dnshare.gridUI.updateRow(oldHash[id].row, newHash[id]);
						
						dnshare.gridUI.highlightRow	( oldHash[id].row );
					}
					else
						newHash[id]=oldHash[id];
				}
					
			if(message.length){
				dnshare.fireNotification(message);
			}
		
		}else{
			
			for(var i=data.length-1;i>=0;i--){
				dnshare.gridUI.addRow(data[i], 0);
				newHash[data[i].id].row = dnshare.gridUI.getRecord(0);
				
			}
		}
		dnshare.oldData = newHash;
	},
	
	_makeDS: function( oSrc ) {
		var ds = new YAHOO.util.DataSource( oSrc );
		ds.parseXMLData = this._parseXML;
		ds.responseType = YAHOO.util.DataSource.TYPE_XML;
		ds.responseSchema = {
			rootNode: "feed",
		    resultNode: "entry",
			fields: ["content@src", "author/name", "category@label", "id", 
				"title", "updated", "link@href"]
		};
		
		
		return ds;
	},

	_makeXMLDoc: function(strContent) {
		var parser = new DOMParser();
    	var doc = parser.parseFromString(strContent, "text/xml");
    	return doc;
	},
	
	_validateXMLDoc: function(oDoc) {
		return oDoc && (oDoc.nodeType == 9);
	},
	
	// YUI's data DataSource#parseXMLData just doesn't cut it, as it can't do 
	// basic XPath queries. We override here the method in the library.
	_parseXML: function ( /*not used*/oRequest, oRawResponse ) {
		var owner = this.parseXMLData.owner;
		var isDocOK = owner._validateXMLDoc ( oRawResponse );
		if (isDocOK) {
			var doc = oRawResponse;
			var schemaOK = this.responseSchema.resultNode? true: false;
			if(schemaOK) {
				var allEntriesRecordsets = [];
				var entryNodeName = this.responseSchema.resultNode;
				var rootNodeName = this.responseSchema.rootNode;
				var rootNode = doc.getElementsByTagName(rootNodeName)[0];
				var entries = doc.getElementsByTagName(entryNodeName);
				// Loop through all the entries
				for(var i=0; i<entries.length; i++) {
					var entry = entries[i];
					if(entry.parentNode!=rootNode) continue;
					var thisEntryRecordset = {};
					// Loop through the records fields in the schema
					for(var j=0; j<this.responseSchema.fields.length; j++) {
						var fieldName = this.responseSchema.fields[j];
						var bFieldNameUsesXPath = /[@\/]/.test(fieldName);
						// If the field name contains an XPath, resolve to
						// deepest node and/or attribute.
						// NOTE: this implementation only supports the single 
						// 		 slash ("/") and at ("@") separators.
						if (bFieldNameUsesXPath) {
							var pathSegments = fieldName.split("/").reverse();
							var node = null;
							while(pathSegments.length) {
								var parentNode = node? node: entry;
								var segment = pathSegments.pop();
								if( !/@/.test(segment) ) {
									node = parentNode.
										getElementsByTagName(segment)[0];
									if(!node) {break;}
								} else {
									var subsegments = segment.split("@");
									node = parentNode.
										getElementsByTagName(subsegments[0])[0];
									if(!node) {break;}
									node = node.getAttributeNode(subsegments[1]);
								}
							}
							var recordName = fieldName.replace(/[@\/]/g, "_");
							var recordValue = null;
							// element
							if (node.nodeType==1) {
								if (node.firstChild &&
									node.firstChild.nodeType==3) {
									recordValue = node.firstChild.nodeValue;
								}
							}
							//attribute
							if(node.nodeType==2) {
								if(node.nodeValue) {
									recordValue = node.nodeValue;
								}
							}
							thisEntryRecordset[recordName] = recordValue;
							continue;
						} else {
							// Just get the text value of the first node having 
							// the <fieldName> name inside the current entry 
							// node.
							var recordValue = null;
							var node = entry.getElementsByTagName(fieldName)[0];
							if(node) {
								if (node.firstChild &&
									node.firstChild.nodeType==3) {
									recordValue = node.firstChild.nodeValue;
								}
							}
							thisEntryRecordset[fieldName] = recordValue;
						}
					}
					allEntriesRecordsets.push(thisEntryRecordset);
				}
				return { 'results': allEntriesRecordsets };
			}
		}
		return { 'error': true };
	},
}

YAHOO.register("DocsFeedParser", DocsFeedParser, {version: "1", build: "1"});