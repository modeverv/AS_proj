function SettingSystem() {
	this.$init();
}

SettingSystem.prototype = {
	$init: function() {
		this.elPollTime =  YAHOO.util.Dom.get("pollTime");
		this.elMinimizeTray =  YAHOO.util.Dom.get("minimizeTray");
		this.elSaveButton =  YAHOO.util.Dom.get("saveButton");
		//
		var _self = this;
		YAHOO.util.Event.addListener (this.elSaveButton, 'click', function() {
			_self._saveSettings();	
		});
		//
		this.elPollTime.value = getPollTime();
		this.elMinimizeTray.checked = getMinimizeToTray();
	},
	
	/**
	 * Save button callback
	 */
	_saveSettings: function() {
		var pollTime = Number(this.elPollTime.value);
		if (isNaN(pollTime) || pollTime < 0.5) {
			alert("Invalid poll time. A number greater than 0.5 is required.");
			return;
		}
		setPollTime(pollTime);
		setMinimizeToTray(this.elMinimizeTray.checked);
	},
	
	/**
	 * Get the current poll time
	 */
	getPollTime: function() {
		return this.elPollTime.value;
	},
	
	/*
	 * Get the current minimize to tray value
	 */
	getMinimizeToTray: function() {
		this.elMinimizeTray.checked;
	}
	
}

YAHOO.register("SettingSystem", SettingSystem, {version: "1", build: "1"});