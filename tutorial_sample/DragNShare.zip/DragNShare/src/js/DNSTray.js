function DNSTray() {
	this.$init();
}

DNSTray.prototype = {
	$init : function() {
		this._loadIcon();
	},
	
	_loadIcon: function() {
		var loader = new air.Loader();
		var _self = this;
		loader.contentLoaderInfo.addEventListener(air.Event.COMPLETE, function(event){
			var loader = air.Loader(event.target.loader);
			var image = air.Bitmap(loader.content);
			air.NativeApplication.nativeApplication.icon.bitmaps = [image.bitmapData];
			var menu = new air.NativeMenu();
			var item_show = new air.NativeMenuItem('Show');
			item_show.addEventListener( air.Event.SELECT , _self.showApplication);
			menu.addItem(item_show);
			//
			var item_hide = new air.NativeMenuItem('Hide');
			item_hide.addEventListener( air.Event.SELECT , function(ev) {nativeWindow.visible = false});
			menu.addItem(item_hide);
			//
			var item_sel = new air.NativeMenuItem("", true);
			menu.addItem(item_sel);
			//
			var item_exit = new air.NativeMenuItem('Exit');
			item_exit.addEventListener( air.Event.SELECT , function(ev) {nativeWindow.close()});
			menu.addItem(item_exit);
			
			air.NativeApplication.nativeApplication.icon.menu = menu;
			
			air.NativeApplication.nativeApplication.icon.addEventListener('click', _self.showApplication);

		});
		var request;
		if(air.NativeApplication.supportsDockIcon){
			request = new air.URLRequest("src/icons/AIRApp_128.png");
		}
		else {
			request = new air.URLRequest("src/icons/AIRApp_16.png");
		}
		loader.load(request);
 		air.NativeApplication.nativeApplication.addEventListener(  air.InvokeEvent.INVOKE , _self.showApplication );
	},
	
	minimizeToTray: function(e) {
		if(e.afterDisplayState=='minimized'&&dnshare.Settings.getMinimizeTray()){
			e.preventDefault();
			nativeWindow.visible = false;
		}
	},
	
	showApplication: function() {
		if(nativeWindow.displayState==air.NativeWindowDisplayState.MINIMIZED){
			nativeWindow.restore();
		}			
		nativeWindow.visible = true;
		nativeWindow.activate();
	}
}