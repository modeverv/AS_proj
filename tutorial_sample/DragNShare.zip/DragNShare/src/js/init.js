/**
 * init1.js
 * Groups all initialization code
 */

dnshare.lastNotificationWindow = null;
// app initialization here
dnshare.addAllLoadedListener ( function() {
	//prevent using cookies from browser (on win: IE and on mac: Safari)
	htmlLoader.manageCookies = false;
	dnshare.DocsUploaderSystem = new DocsUploaderSystem();
	dnshare.DocsUploaderSystem.addEventListener("uploadStatus", 
		function( args ) {
			setUploadStatus(args);
		}
	);
	dnshare.DNSContextMenu = new DNSContextMenu();
	dnshare.DNSTray = new DNSTray();
	dnshare.Settings = new Settings();
	dnshare.clientLoginSystem = new ClientLoginSystem();
	nativeWindow.addEventListener (
		air.NativeWindowDisplayStateEvent.DISPLAY_STATE_CHANGING, function(ev) {
			dnshare.DNSTray.minimizeToTray(ev);
		}
	);
	nativeWindow.addEventListener( air.Event.CLOSING, function() {
		if(dnshare.lastNotificationWindow) {
			try {
				dnshare.lastNotificationWindow.window.nativeWindow.close();
			} catch(e) {
				dnshare.lastNotificationWindow = null;
			}
		}
	});
	dnshare.initGrid();
	dnshare.initTabs();
	dnshare.initUpload();
	dnshare.doFillInCredentials();
	dnshare.autoLogin();
	dnshare.initSettings();
	showWindow();	
});

var openBrowse = function() {
	dnshare.DocsUploaderSystem.browseToUploadFiles();
}

var saveCredentials = function( credentialsQuery ) {
	// expects something like: "user=my%20User%20Name&pass=my%20pass"
	var pairs = credentialsQuery.split('&');
	for(var i=0; i<pairs.length; i++) {
		var pair = pairs[i].split("=");
		var name = pair[0];
		var value = pair[1];
		var btsValue = new air.ByteArray();
		btsValue.writeUTFBytes(value);
		air.EncryptedLocalStore.setItem(name, btsValue, false);
	}
}

var destroyCredentials = function(){
	air.EncryptedLocalStore.removeItem("user");
	air.EncryptedLocalStore.removeItem("pass");
}

var uploadFiles = function(title){
	dnshare.DocsUploaderSystem.uploadFiles(title);
}

var registerToken = function(token){
	dnshare.DocsUploaderSystem.registerToken(token);
}

var showContextMenu = function(x, y, url) {
	dnshare.DNSContextMenu.showMenu(x, y, url);
}

var setPollTime = function(value) {
	dnshare.Settings.setPollingTime(value);
}

var getPollTime = function() {
	return dnshare.Settings.getPollingTime();
}

var setMinimizeToTray = function(value) {
	dnshare.Settings.setMinimizeTray(value);
}

var getMinimizeToTray = function() {
	return dnshare.Settings.getMinimizeTray();
}

var showSources = function() {
	var src= 'file://' +air.File.applicationResourceDirectory.nativePath+
		'/.src/index.html';
	air.navigateToURL( new air.URLRequest( src ), "_blank" );			
}

var gotoURL = function (url) {
	air.navigateToURL(new air.URLRequest(url), "_blank");
}

var showWindow = function() {
	nativeWindow.visible=true;
}

var dropFiles = function (fileList) {
	dnshare.DocsUploaderSystem.dropFiles(fileList);
}

var fireNotification = function (message) {
	var text = "";
	var mLenghtPlural = '';
	for(var i=0;i<message.length&&i<3;i++) {
		if(i>0) text+="<br />";
		message[i] = message[i].substring(0, 40)+'...';
		text+=message[i];
	}
	if(message.length>1)
		mLenghtPlural='s';
	if(message.length>3)
		text+="<br />more...";
	if(dnshare.lastNotificationWindow){
		try {
			dnshare.lastNotificationWindow.window.nativeWindow.close()
		} catch(e) {
			dnshare.lastNotificationWindow = null;
		}
	}
	var options = new air.NativeWindowInitOptions();
	options.maximizable = false;
	options.minimizable = false;
	options.resizable = false;
	options.systemChrome = 'none';	
	options.transparent = true;
	options.type = air.NativeWindowType.UTILITY;
	var htmlLoader =  air.HTMLLoader.createRootWindow (false, options, false);
	try{
		//since AIR1.5 the htmlLoader will not allow string load in app sandbox
		//surrownded with try/catch in case we are running in older runtime
		//don't need to switch this back to false, because the htmlLoader will die after this call
		htmlLoader.placeLoadStringContentInApplicationSandbox = true;
	}catch(e){}	
	dnshare.lastNotificationWindow = htmlLoader;
	htmlLoader.addEventListener(air.Event.HTML_DOM_INITIALIZE , function(){
		htmlLoader.removeEventListener(air.Event.HTML_DOM_INITIALIZE,
		  arguments.callee);
	htmlLoader.window.nativeWindow.alwaysInFront  = true;
	htmlLoader.window.nativeWindow.addEventListener(air.Event.CLOSING, 
		function() {
			dnshare.lastNotificationWindow = null;			
		});
		htmlLoader.window.doClick = function(){
			htmlLoader.window.nativeWindow.close();
			nativeWindow.visible = true;
			nativeWindow.activate();
			
		}
	});
	htmlLoader.loadString (
		'<html>\n'+
			'<head>\n'+
				'<meta http-equiv="Content-Type" '+
					'content="text/html;charset=UTF-8" />\n'+
				'<script type="text/javascript" '+
					'src="src/js/AIRAliases.js">\n '+
				'</script>\n '+
				'<script type="text/javascript" '+
					'src="src/js/notification.js">\n '+
				'</script>\n '+
				'<link '+ 
				'href="src/css/notifications.css" type="text/css" '+ 
					'rel="stylesheet" />\n'+
			'</head>\n'+
			'<body onload="doLoad()" onunload="doUnload()">\n'+
				'<table width="100%" height="100%" onclick="doClick()">\n'+
					'<tr>\n'+
						'<td valign="middle" align="center">\n'+
							'<span id="notificationText">\n'+
								'<a href="#">\n' +text+ '</a>\n'+
							'</span>\n'+
						'</td>\n'+
					'</tr>\n'+
				'</table>\n'+
				'<div id="mods">\n'+ 
					message.length +
					' change' +
					mLenghtPlural+
				'</div>\n'+
			'</body>\n'+
		'</html>'
	);
}
	
dnshare.doFillInCredentials = function() {
	var targetData = null;
    var storedUserName = null;
    try {
	    storedUserName = air.EncryptedLocalStore.getItem("user");
    } catch (e) {
        window.setTimeout(function() {
            alert("Due to some incompatibility between Beta 2 and Beta 3\n"+
                "the application needs to reset your credentials.\n\n"+
                "You are required to log in again.");
        }, 0);
        air.EncryptedLocalStore.reset();
    }
	if(storedUserName && storedUserName.length) {
		var user = storedUserName.readUTFBytes(storedUserName.length);
		var storedUserPass = air.EncryptedLocalStore.getItem("pass");
		var pass = storedUserPass.readUTFBytes(storedUserPass.length);
		targetData = 'user=' +user+ '&pass=' +pass;
	}
	fillInCredentials(targetData);
}

dnshare.autoLogin = function() {
	if(dnshare.autoLoginOK) {
		dnshare.clientLoginSystem.doLogin();
	}
}

var setUploadStatus = function (e) {
	var upButton = document.getElementById("uploadButton");
	var brButton = document.getElementById("browseButton");
	var cancelButton = document.getElementById('cancelButton');
	var fileUploadPath = document.getElementById("fileUploadPath");
	switch(e.state){
		case 'enableUpload':
		case 'disableUpload':
			if(e.fileName) {
				fileUploadPath.value = e.fileName;
				fileUploadPath.style.display = "";
				cancelButton.style.display = "";
			}
			brButton.disabled=e.state!='disableUpload';
			upButton.disabled=e.state=='disableUpload';
			break;
		case 'start':
			brButton.disabled = true;
			upButton.disabled = true;
			// cancelButton.disabled = true;
			cancelButton.style.display = "none";
			break;
		case 'complete':
			brButton.disabled = false;
			upButton.disabled = true;
			fileUploadPath.style.display = "none";
			cancelButton.style.display = "none";
			dnshare.clientLoginSystem.refreshDocs();
			break;
		case 'progress':
			break;
		case 'error':
			alert('Upload error: ' + e.message);
			brButton.disabled = false;
			upButton.disabled = false;
			cancelButton.style.display = "none";
			fileUploadPath.style.display = "none";
				break;
		}
	}
		
var fillInCredentials = function (credentialsQuery) {
	if(!credentialsQuery) { return };
	var pairs = credentialsQuery.split('&');
	for(var i=0; i<pairs.length; i++) {
		var pair = pairs[i].split("=");
		var name = pair[0];
		var value = decodeURIComponent(pair[1]);
		if(name == "user") {
			document.getElementById("usernameField").value = value;
		}
		if(name == "pass") {
			document.getElementById("passwordField").value = value;
		}
	}
	// stored credentials will persist until a logout occures
	document.getElementById("rememberMeCheck").checked = true;
	// automatically login, now that we have the credentials
	dnshare.autoLoginOK = true;
}

// initialize the grid UI element
dnshare.initGrid = function() {
	var dummyDS = new YAHOO.util.DataSource([]);
	dummyDS.responseType = YAHOO.util.DataSource.TYPE_JSARRAY;
	dummyDS.responseSchema = {};
	dnshare.customDateFormatter = function(elCell, oRecord, oColumn, oData) {
		var sRaw = oRecord.getData('updated');
		var dsPat = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})\.(\d){3}Z/;
		elCell.innerHTML = sRaw.replace(dsPat, "$2/$3/$1 $4:$5:$6");

	}
	dnshare.gridHeaders = [
	    { key:"title", 	label: "Document Title", sortable:true },
	    { key:"author_name",	label: "Created By", sortable:true },
	    { key:"category_label",	label: "Category", sortable:true },
	    { key:"updated",		label: "Last Updated", sortable:true, formatter: 
	    								dnshare.customDateFormatter }
    ];
    dnshare.gridUI = new YAHOO.widget.DataTable("gridUI",
    	dnshare.gridHeaders, dummyDS);
    dnshare.gridUI.showTableMessage ( YAHOO.widget.DataTable.MSG_LOADING,
    	YAHOO.widget.DataTable.CLASS_LOADING);
     // add context menu and dbl click
     dnshare.gridUI.getTbodyEl().addEventListener("contextmenu", 
     	dnshare.onTableClick);
     dnshare.gridUI.subscribe("rowDblclickEvent", dnshare.onTableDblClick); 
}

// show context menu on current row
// only open on Google Documents for now
dnshare.onTableClick = function (event) {
	var elRow = dnshare.gridUI.getTrEl(event.target);
	var record = dnshare.gridUI.getRecord(elRow);
	showContextMenu(event.x, event.y, 
		record.getData("link_href"));
	event.preventDefault();
}

// handler for row double click
// open the document on google documents
dnshare.onTableDblClick = function(event) {
	var record = dnshare.gridUI.getRecord(event.target);
	gotoURL(record.getData("link_href"));
}

//fire notification
dnshare.fireNotification = function(messages){
	fireNotification(messages);
}

// initialize the upload for file UI element
dnshare.initUpload = function() {
	var brButton = document.getElementById("browseButton");
	var upButton = document.getElementById("uploadButton");
	var pathText = document.getElementById("fileUploadPath");
	var cancelButton = document.getElementById('cancelButton');
	
	YAHOO.util.Event.addListener (brButton, 'click', function() {
		openBrowse();
	});	

	YAHOO.util.Event.addListener (cancelButton, 'click', function() {
		pathText.style.display="none";
		cancelButton.style.display="none";
		upButton.disabled = true;
		brButton.disabled = false;
	});	

	YAHOO.util.Event.addListener (upButton, 'click', function() {
		uploadFiles(pathText.value);
	});

	
	pathText.style.display="none";
	cancelButton.style.display="none";
	upButton.disabled=true;
	brButton.disabled = false;
}


// initialize the outer tab view UI element
dnshare.initTabs = function () {
	dnshare.myTabs = new YAHOO.widget.TabView("tabUI");
	dnshare.docsTab = dnshare.myTabs.getTab(1);
    dnshare.myTabs.addListener('activeTabChange', function(e){
        e.prevValue.get('labelEl').parentNode.style.visibility = "hidden";
        setTimeout(function(){
        e.prevValue.get('labelEl').parentNode.style.visibility = ""; 
        }, 0);
 		e.newValue.get('labelEl').parentNode.style.visibility = "hidden";
		setTimeout(function(){
			e.newValue.get('labelEl').parentNode.style.visibility = ""; 
		}, 0);        
    });
}

dnshare.initSettings = function() {
	dnshare.settings = new SettingSystem();
}